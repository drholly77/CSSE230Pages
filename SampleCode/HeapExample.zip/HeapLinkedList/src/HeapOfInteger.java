
public class HeapOfInteger {
	
	private Node head;
	private int heapZ;
	
	// ------------------------------------------
		
	public HeapOfInteger() {
		this.head = null;
		this.heapZ = 0;
	}
	
	// ------------------------------------------
	
	public int deleteMin() 
	// requires: |this| > 0
	// ensures: deleteMin = min value of heap and
	//          min value is removed from heap
	{
		Node p = this.head;
		Node trailer = null;
		
		Node currentMin = this.head;
		Node trailerOfMin = null;
		
		while (p != null) {
			// Traverse list to find Node with minimum value
			if(p.value < currentMin.value) {
				currentMin = p;
				trailerOfMin = trailer;
			} // end if
			trailer = p;
			p = p.next;			
		} // end while
		
		if (trailerOfMin == null)  {
			// 1st node in linked list has minimum value
			this.head = currentMin.next;
		} else {
			// Some node after 1st node has minimum value
			trailerOfMin.next = currentMin.next;
		} // end if

		this.heapZ--;
		return currentMin.value;
	} // deleteMin
	
	// ------------------------------------------
	
	public void insert(int x)
	// ensures: x added to heap
	{
		this.head = new Node(x, this.head);	
		this.heapZ++;	
	} // insert
	
	// ------------------------------------------
	
	public int size() 
	// ensures size = |this|
	{
		return this.heapZ;
	} // size
	
} // HeapOfInteger Class
