class Node {
	public int value;
	public Node next;
	
	// ------------------------------------------
		
	public Node() {
		this.value = 0;
		this.next = null;
	} // Node
	
	// ------------------------------------------
		
	public Node(int x, Node p) {
		this.value = x;
		this.next = p;
	} // Node
	
} // Node Class