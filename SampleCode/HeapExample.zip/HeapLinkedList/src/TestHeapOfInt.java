import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;

import org.junit.jupiter.api.Test;

class TestHeapOfInt {
	
	private void displayArray(int[] a) {
		System.out.print("[");
		for (int k = 0; k < a.length; k++) {
			System.out.print(a[k]);
			System.out.print(((k + 1) < a.length) ? "," : "");
		} // end for
		System.out.print("]");		
	} // displayArray
	
	// ------------------------------------------
		
	@Test
	void testN01() {
		int a1[] = {47,2,10,200,21,5};		
		HeapOfInteger h1 = new HeapOfInteger();
		
		assertEquals(0, h1.size());
		for (int k = 0; k < a1.length; k++) {
			h1.insert(a1[k]);
		} // end for
		
		Arrays.sort(a1);  // Now a1 = [2,5,10,21,47,200]
		// displayArray(a1);
		
		for (int k = 0; k < a1.length; k++) {
			assertEquals(a1[k], h1.deleteMin());
			assertEquals(a1.length - (k + 1), h1.size());
		} // end for
		
	} // testN01

}
