package mirror;

/**
 * A simple BinaryNode class.
 *
 * @author Matt Boutell.
 *         Created May 24, 2011.
 */
public class BinaryNode {
	/** Data for this node */
	int element;

	/** Left child */
	BinaryNode left;
	
	/** Right child */
	BinaryNode right;
	
	/** Right child */
	// int rank;

	//BinaryNode NULL_NODE = new BinaryNode(0, null, null);
	
	
	/**
	 * Creates a binary node from the given arguments.
	 * 
	 * @param element 
	 * @param left 
	 * @param right 
	 */
	public BinaryNode(int element, BinaryNode left, BinaryNode right) {
		this.element = element;
		this.left = left;
		this.right = right;
	}
	
	@Override
	public String toString() {
		return 	(this.left == null ? "" : this.left.toString()) + 
				this.element + 
				(this.right == null ? "" : this.right.toString());
	}
	
	/**
	 * Creates a mirror reflection (left to right) of 
     * the entire tree rooted at node t.
	 *
	 * @param t The root of a tree.
	 * @return The root of a new tree that is a mirror 
     * image of the tree  whose root is node t.
	 */

	public static BinaryNode mirror(BinaryNode t) {
		if (t == null) { return null; }
		
		BinaryNode newLeft = mirror(t.right); 
		BinaryNode newRight = mirror(t.left);
		return new BinaryNode(t.element, newLeft, newRight);

		// Super-concise:
//		return 	t == null ? 
//				null : 
//				new BinaryNode(t.element, mirror(t.right), mirror(t.left));

		
		
 		// This solution destroys the original tree. Ouch!
//		BinaryNode temp = mirror(t.left);
//		t.left = mirror(t.right);
//		t.right = temp;
//		return t;

		// return null;
	}



}
