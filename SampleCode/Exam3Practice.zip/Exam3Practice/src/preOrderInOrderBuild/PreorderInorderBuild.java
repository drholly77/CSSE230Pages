package preOrderInOrderBuild;

// This is the class you should modify for problem 2B.

public class PreorderInorderBuild {

	public static BinaryNode buildFromPreOrderInorder(String pre, String in) {
		// TODO: Fill in the details of this method,
		// and perhaps add a recursive helper method.
		// Suggestion: For the recursive calls, you probably want to pass
		// substrings of the pre and in strings.
		
		return null;  // Replace with your solution.
	}
}
