import java.util.Arrays;
import java.util.List;

public class Driver {

	enum Cards {
		DA, D2, D3, D4, D5, D6, D7, D8, D9, D10, DJ, DQ, DK,
		HA, H2, H3, H4, H5, H6, H7, H8, H9, H10, HJ, HQ, HK,
		CA, C2, C3, C4, C5, C6, C7, C8, C9, C10, CJ, CQ, CK,
		SA, S2, S3, S4, S5, S6, S7, S8, S9, S10, SJ, SQ, SK;

		public String toString() {
			final String suitNames[] = 
				{"diamonds", "hearts", "clubs", "spades"};
			final String rankNames[] = 
				{"ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "jack", "queen", "king"};			
			
			return rankNames[this.ordinal() % 13] + " of " + suitNames[this.ordinal() / 13];
		} // toString
	} // Cards
	
	public static void main(String[] args) {
		
		Cards myCard = Cards.C7;
		System.out.println(myCard.name() + " " + myCard.toString() + " " + myCard.ordinal());
		
		List<Cards> deck = Arrays.asList(Cards.values());
		for (Cards oneCard : deck) {
			System.out.println(oneCard.name() + "\t" + oneCard + "\t" + oneCard.ordinal());			
		}

// The following is a lambda expression that does the same thing as the for loop above
//		Arrays.asList(Cards.values()).forEach(oneCard -> 
//        System.out.println(oneCard.name() + "\t" + oneCard + "\t" + oneCard.ordinal());

	}
	
}
