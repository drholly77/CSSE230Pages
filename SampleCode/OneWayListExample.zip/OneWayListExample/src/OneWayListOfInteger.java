
public class OneWayListOfInteger {

	private class BooleanContainerV1 {
		// This version of the Container allows the client
		// program to just dot its way into the 'value' field
		// and set value to either true or false
		//
		// Because it's public, there's no need for getters/setters
		//
		// Because it's the only field and no other internal part of
		// the class depends on 'value' allowing the client 
		// to change it is not dangerous
		
		public boolean value;

		public BooleanContainerV1() {
			// default constructor
			this.value = false;
		}	
		
		public BooleanContainerV1(boolean value) {
			// parameterized constructor
			this.value = value;
		}		
	}

	private class BooleanContainerV2 {
		// Because 'value' field is private, this version 
		// of the Container does not allow the client
		// program to just dot its way into the 'value' field
		// and set value to either true or false
		//
		// So this class must export getters/setters and the
		// client must use getters/setters to modify or access
		// the 'value' field
		
		private boolean value;

		public BooleanContainerV2() {
			// default constructor
			this.value = false;
		}
		
		public BooleanContainerV2(boolean value) {
			// parameterized constructor
			this.value = value;
		}

		public boolean isValue() {
			return value;
		}

		public void setValue(boolean value) {
			this.value = value;
		}
		
	}

	private Node head;
	private Node NULL_NODE = new Node();
	
	private class Node {
		int data;
		Node next;
		
		// ------------------------------
		
		Node () 
		// default constructor 
		{
			this.data = 0;
			this.next = null;
		} // Node()
		
		// ------------------------------
		
		Node (int x) 
		// parameterized constructor
		{
			this.data = x;
			this.next = NULL_NODE;
		} // Node(x)
		
		// ------------------------------
		
		public Node insert(int x) 
		// ensures: a new node is created and added to the 
		//          end of the linked list with x in the data 
		//          field of the new node
		{
			if (this == NULL_NODE) {
				return new Node(x);
			} else {
				this.next = this.next.insert(x);
				return this;
			} // end if
		} // insert	

		// 'produce' a value back through wasRemoved parameter to the caller
		// at the same time return a Node reference to the caller
		public Node remove(int x, BooleanContainerV2 wasRemoved) {
			if (this == NULL_NODE) {
				wasRemoved.setValue(false);
				return NULL_NODE;
			} else if (this.data == x) {
				wasRemoved.setValue(true);
				return this.next;
			} else {
				this.next = this.next.remove(x, wasRemoved);
				return this;
			} // end if
		} // remove
	} // Node

	// ------------------------------------------------------
	// Begin OneWayListOfInteger method section
	// ------------------------------------------------------	
	
	OneWayListOfInteger() 
	// default constructor
	{
		head = NULL_NODE;
	} // oneWayListOfInteger() 

	// ------------------------------------------------------	
	
	public void insert(int x) 
	// ensures: x is added to the end of the list
	{
		head = head.insert(x);
	} // insert
	
	// ------------------------------------------------------	
	
	public void remove(int x) 
	// ensures: x is added to the end of the list
	{
		BooleanContainerV2 wR = new BooleanContainerV2();
		head = head.remove(x, wR);

		
//		2 was removed
//		0 was removed
//		4 was removed
//		11 was not removed
		System.out.println(x + " was " + (wR.value ? "" : "not ") + "removed");
	} // insert

	// ------------------------------------------------------	
	
	public String toString()
	{
		StringBuilder sb1 = new StringBuilder("<");
		
		Node p = head;
		while (p != NULL_NODE) {
			sb1.append(p.data);
			p = p.next;
			if (p != NULL_NODE) {
				sb1.append(", ");
			} // end if
		} // end while
		sb1.append(">");
		return sb1.toString();
	} // toString

}
