import static org.junit.Assert.*;
import org.junit.Test;

public class OneWayListIntTest {

	
	
	@Test
	public void emptyList() {
		OneWayListOfInteger s1 = new OneWayListOfInteger();

		assertEquals("<>", s1.toString());
	}
	
	@Test
	public void nonEmptyList() {
		OneWayListOfInteger s1 = new OneWayListOfInteger();
		int x1;
		
		for (int k = 0; k < 5; k++) {
			x1 = k;
			s1.insert(x1);
		} // end for
		//		System.out.println(s1.toString());
		assertEquals("<0, 1, 2, 3, 4>", s1.toString());
	}
	
	@Test
	public void testRemove() {
		OneWayListOfInteger s1 = new OneWayListOfInteger();
		int x1;
		
		// Test remove from an empty list - an edge case
		assertEquals("<>", s1.toString());
		s1.remove(47);
		assertEquals("<>", s1.toString());
		
		// Test remove, where remove drives the list back to empty
		// This also is testing in and around the edge
		s1.insert(5);
		assertEquals("<5>", s1.toString());
		s1.remove(5);
		assertEquals("<>", s1.toString());
		
		// Now test a number of non-empty list removals
		for (int k = 0; k < 5; k++) {
			x1 = k;
			s1.insert(x1);
		} // end for

		
		// This set of tests removes at the following locations:
		// middle, front end, tail end 
		//

		// If the 'remove' works for all these cases, then that gives
		// us more confidence that it will work for all cases
		assertEquals("<0, 1, 2, 3, 4>", s1.toString());
		s1.remove(2);
		assertEquals("<0, 1, 3, 4>", s1.toString());

		// Test an non-empty edge case
		s1.remove(0);
		assertEquals("<1, 3, 4>", s1.toString());
		
		// Test an non-empty edge case
		s1.remove(4);
		assertEquals("<1, 3>", s1.toString());
		
		// Tests a remove of a value not present in a non-empty list
		s1.remove(11);
		assertEquals("<1, 3>", s1.toString());
	} // testRemove

}
